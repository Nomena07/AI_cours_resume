from fastapi import FastAPI, UploadFile, File, Form
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse
from transformers import pipeline
import fitz
import shutil
import os
import random
import re

app = FastAPI()

# --- VARIABLES GLOBALES ---
document_chunks = []
key_concepts = []
qa_pipeline = None
gen_pipeline = None

# --- 1. CHARGEMENT DES MODÈLES IA (FRANÇAIS) ---
print("--- Initialisation de l'IA de Révision (Français) ---")
try:
    # Modèle de réponse : CamemBERT spécialisé sur SQuAD FR
    print("Chargement du cerveau de réponse (CamemBERT)...")
    qa_pipeline = pipeline("question-answering", model="etalab-ia/camembert-base-squadFR-fquad-piaf")
    
    # Modèle de Quiz : T5 spécialisé dans la génération de questions en français
    print("Chargement du cerveau de quiz (T5-FR)...")
    gen_pipeline = pipeline("text2text-generation", model="mrm8488/t5-base-french-question-generation")
    
    print("✅ IA Française prête.")
except Exception as e:
    print(f"❌ Erreur de chargement : {e}")

# --- 2. LOGIQUE D'ANALYSE ET D'ENTRAÎNEMENT ---
def analyser_texte(texte):
    global document_chunks, key_concepts
    # Nettoyage
    texte = re.sub(r'\s+', ' ', texte)
    # Découpage en blocs de concepts (600 caractères)
    document_chunks = [texte[i:i+600] for i in range(0, len(texte), 500)]
    # Extraction de mots-clés importants (mots longs de plus de 7 lettres)
    mots = re.findall(r'\b\w{7,}\b', texte.lower())
    frequences = {}
    for m in mots: frequences[m] = frequences.get(m, 0) + 1
    key_concepts = sorted(frequences, key=frequences.get, reverse=True)[:15]
    print(f"🧠 Analyse terminée : {len(document_chunks)} concepts mémorisés.")

# --- 3. ROUTES API ---

@app.post("/upload")
async def upload_pdf(file: UploadFile = File(...)):
    try:
        path = "temp.pdf"
        with open(path, "wb") as f: shutil.copyfileobj(file.file, f)
        doc = fitz.open(path)
        texte_complet = "".join([page.get_text() for page in doc])
        doc.close()
        
        if len(texte_complet.strip()) < 50:
            return JSONResponse(status_code=400, content={"message": "Document vide."})
        
        analyser_texte(texte_complet)
        return {"message": "Entraînement réussi !", "concepts": key_concepts[:5]}
    except Exception as e:
        return JSONResponse(status_code=500, content={"message": str(e)})

@app.post("/ask")
async def poser_question(question: str = Form(...)):
    global document_chunks, qa_pipeline
    if not document_chunks or not qa_pipeline:
        return {"answer": "Veuillez d'abord charger un document."}
    try:
        # L'IA cherche la réponse dans les premiers blocs mémorisés
        contexte = " ".join(document_chunks[:5])
        resultat = qa_pipeline(question=question, context=contexte)
        return {"answer": resultat['answer']}
    except:
        return {"answer": "Désolé, je ne trouve pas la réponse dans le cours."}

@app.get("/generate_full_quiz")
async def generer_quiz():
    global document_chunks, gen_pipeline, qa_pipeline, key_concepts
    
    if not document_chunks:
        return JSONResponse(status_code=400, content={"error": "Aucun document chargé."})

    try:
        # Choix d'un segment aléatoire
        segment = random.choice(document_chunks)
        
        # Génération de la question (Mode IA)
        res = gen_pipeline(segment, max_length=64)
        question_texte = res[0]['generated_text'].strip()
        
        # Identification de la bonne réponse
        ans_res = qa_pipeline(question=question_texte, context=segment)
        bonne_reponse = ans_res['answer']

        # Création des mauvaises réponses (distracteurs) à partir des concepts clés
        distracteurs = random.sample([c for c in key_concepts if c.lower() not in bonne_reponse.lower()], min(3, len(key_concepts)))
        options = list(set(distracteurs + [bonne_reponse]))
        while len(options) < 4: options.append("Concept secondaire")
        random.shuffle(options)

        return {
            "question": question_texte,
            "options": options,
            "answer": bonne_reponse
        }
    except Exception as e:
        print(f"Erreur Quiz: {e}")
        return JSONResponse(status_code=500, content={"error": "Échec de la génération."})

# Montage des fichiers statiques
if os.path.exists("static"):
    app.mount("/", StaticFiles(directory="static", html=True), name="static")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
